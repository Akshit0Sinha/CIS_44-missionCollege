
public class Node {
	// vars
	String textState;
	Node last;
	Node next;

// base variable insantiation
	public Node(String textState, Node last, Node next) {
		this.textState = textState;
		this.last = last;
		this.next = next;
	}
}

public class Text {
	private Node currentNode;

	public Text() {
		// Start with an initial empty string state
		Node initialNode = new Node("", null, null);
		this.currentNode = initialNode;
	}

	public void add(String newText) {
		// Build new text state
		String updatedText = currentNode.textState + newText;

		// Create new node
		Node newNode = new Node(updatedText, currentNode, null);

		// Clear redo history
		currentNode.next = null;

		// Link new node
		currentNode.next = newNode;
		currentNode = newNode;
	}

// what's at current node
	public void printCurrent() {
		System.out.println("Current text: \"" + currentNode.textState + "\"");
	}

// repeat current node
	public String redo() {
		if (currentNode.next != null) {
			currentNode = currentNode.next;
			return currentNode.textState;
		} else {
			System.out.println("Nothing to test.");
			return currentNode.textState;
		}
	}

// remove current node addition
	public String undo() {
		if (currentNode.last != null) {
			currentNode = currentNode.last;
			return currentNode.textState;
		} else {
			System.out.println("Nothing to remove.");
			return currentNode.textState;
		}
	}
}

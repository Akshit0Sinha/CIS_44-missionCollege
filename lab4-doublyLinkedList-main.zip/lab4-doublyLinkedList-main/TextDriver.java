import java.util.Scanner;

public class TextDriver {
	public static void main(String[] args) {
		// instantiation
		Scanner in = new Scanner(System.in);
		Text editor = new Text();

		int choice;
		// ui
		do {
			System.out.println("\n--- Simple Text Editor ---");
			System.out.println("1. Add text");

			System.out.println("2. Redo");
			System.out.println("3. Print current text");
			System.out.println("9. Undo");
			System.out.println("0. Exit");
			System.out.print("Enter choice: ");
			choice = in.nextInt();
			in.nextLine();
			// different scanner input -> throws case args
			switch (choice) {
			case 1:
				System.out.print("Enter text to add: ");
				String text = in.nextLine();
				editor.add(text);
				break;
			case 9:
				editor.undo();
				break;
			case 2:
				editor.redo();
				break;
			case 3:
				editor.printCurrent();
				break;
			case 0:
				System.out.println("Exiting editor...");
				choice = 5;
				break;
			default:
				System.out.println("Invalid choice. Try again.");
			}

		} while (choice != 5);

		in.close();
	}
}
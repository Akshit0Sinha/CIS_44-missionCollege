import java.util.Arrays;

public class DynamicArray<S> {
	private static final int init_Max = 10;
	private S[] data;
	private int size;

	public DynamicArray() {
		data = (S[]) new Object[init_Max];
		size = 0;
	}

	// add item to index end
	public void add(S element) {
		if (size == data.length) {
			resize();
		}
		data[size++] = element;
	}

	// validate value at index
	private void checkIndex(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("Index " + index + " out of bounds. Size = " + size);
		}
	}

	// get current value at that index
	public S get(int index) {
		checkIndex(index);
		return data[index];
	}

	// remove element at index
	public S remove(int index) {
		checkIndex(index);
		S removed = data[index];
		int numMoved = size - index - 1;
		if (numMoved > 0) {
			System.arraycopy(data, index + 1, data, index, numMoved);
		}
		data[--size] = null;
		// free unused slot
		return removed;
	}

	// resize array when full
	private void resize() {
		int newCapacity = data.length * 2;
		data = Arrays.copyOf(data, newCapacity);
	}

	// return # elements in array
	public int size() {
		return size;
	}

	@Override
	public String toString() {
		return Arrays.toString(Arrays.copyOf(data, size));
	}

}

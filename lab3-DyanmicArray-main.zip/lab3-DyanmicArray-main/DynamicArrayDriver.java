
public class DynamicArrayDriver {

	public static void main(String[] args) {
		DynamicArray<Integer> n = new DynamicArray<>();
		// add elements
		for (int i = 1; i <= 12; i++) {
			n.add(i * 10);
		}
		// print elements in the array created randomly
		System.out.println("Numbers: " + n);
		System.out.println("Element at index 5: " + n.get(5));

		System.out.println("Removed element: " + n.remove(5));
		System.out.println("After removal: " + n);

		System.out.println("Final size: " + n.size());

	}

}

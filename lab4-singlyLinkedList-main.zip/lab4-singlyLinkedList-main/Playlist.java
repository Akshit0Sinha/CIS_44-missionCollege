
public class Playlist {
	// Inner class rep Node in the singlyLinkedList

	private static class Node {
		// song stored
		Song s;
		// reference next node
		Node next;

		Node(Song s) {
			// store song
			this.s = s;
			this.next = null;
		}
	}

	// singly list features
	private Node head;
	private Node tail;
	private Node current;
	private int size;

	public Playlist() {
		// base descriptors of linked list
		head = null;
		tail = null;
		current = null;
		size = 0;
	}

	// add song to end of playlist
	public void addSong(Song s) {
		Node newNode = new Node(s);
		if (head == null) {
			head = tail = newNode;
			current = head;
		} else {
			tail.next = newNode;
			tail = newNode;
		}
		size++;
		System.out.println("Added: " + s);
	}

	// shows songs in playlist
	public void displayPlaylist() {
		if (head == null) {
			System.out.println("Playlist is empty.");
			return;
		}
		// Start from head
		Node temp = head;
		System.out.println("Playlist:");
		// cycle to end and repeat
		while (temp != null) {
			System.out.println(" - " + temp.s);
			temp = temp.next;
		}
	}

	// return # songs
	public int getSize() {
		return size;
	}

	// show next song in playlist
	public void playNext() {
		if (current == null) {
			System.out.println("Playlist is empty.");
			return;
		}
		System.out.println("Playing: " + current.s);
		if (current.next != null) {
			// Go to the next song
			current = current.next;
		} else {
			current = head; // cycle to #1 song
		}
	}

	// remove first song name search by title
	public void removeSong(String title) {
		if (head == null) {
			return;
		}

		// head removal
		if (head.s.getTitle().equals(title)) {
			if (current == head) {
				current = head.next;
			}
			head = head.next;
			if (head == null) {
				tail = null;
			}
			size--;
			System.out.println("Removed song with title: " + title);
			return;
		}

		// removing node somewhere else in LinkedList
		Node p = head;
		Node c = head.next;
		while (c != null) {
			if (c.s.getTitle().equals(title)) {
				p.next = c.next;
				if (c == tail) {
					tail = p;
				}
				if (current == c) {
					if (c.next != null) {
						current = c.next;
					} else {
						current = head;
					}
				}

				size--;
				System.out.println("Removed song with title: " + title);
				return;
			}
			p = c;
			c = c.next;
		}
		// song dne
		System.out.println("Song not found: " + title);

	}

}


public class Song {
	// set variables
	private String title;
	private String artist;

	public Song(String title, String artist) {
		// initialize variables
		this.artist = artist;
		this.title = title;

	}

	public String getArtist() {
		// return artist
		return artist;
	}

	public String getTitle() {
		// return name of song
		return title;
	}

	@Override
	public String toString() {
		// string rep. song
		return String.format("\"%s\" by %s", title, artist);
	}
}

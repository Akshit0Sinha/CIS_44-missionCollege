import java.util.Scanner;
public class PlaylistDriver {

	public static void main(String[] args) {
		// Create playlist

		Playlist p = new Playlist();
		Scanner in = new Scanner(System.in);
		int choice;

		do {
			// Display menu options
			System.out.println("\n--- Playlist Menu ---");
			System.out.println("1. Add song");
			System.out.println("2. Remove song");
			System.out.println("8. Display playlist");
			System.out.println("9. Exit");
			System.out.println("0. Play next song");
			System.out.print("Enter choice: ");
			choice = in.nextInt();
			in.nextLine();

			switch (choice) {
			case 1:
				// Add a new song
				System.out.print("Enter song title: ");
				String title = in.nextLine();
				System.out.print("Enter artist name: ");
				String artist = in.nextLine();
				p.addSong(new Song(title, artist)); // Add song to playlist
				break;
			case 2:
				// Remove a song by title
				System.out.print("Enter title of song to remove: ");
				String removeTitle = in.nextLine();
				p.removeSong(removeTitle);
				break;
			case 0:
				// Play the next song in the playlist
				p.playNext();
				break;
			case 8:
				// Display all songs
				p.displayPlaylist();
				break;
			case 9:
				// Exit program
				System.out.println("Exiting application.");
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (choice != 9);

		in.close();
		// Close
	}
}


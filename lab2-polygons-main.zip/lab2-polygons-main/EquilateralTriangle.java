//only need 1 of the equal sides from isosceles triangles for multiplying to find area
public class EquilateralTriangle extends IsoscelesTriangle {
	public EquilateralTriangle(double side) {
		super(side, side);
	}

}

//extends for 7 sided-shape to then pull from regular polygon parameters for area and perimeter
public class Hexagon extends RegularPolygon {
	public Hexagon(double sideLength) {
		super(6, sideLength);
	}
}

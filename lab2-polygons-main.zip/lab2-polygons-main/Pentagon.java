////extends for 5 sided-shape to then pull from regular polygon parameters for area and perimeter

public class Pentagon extends RegularPolygon {
	public Pentagon(double sideLength) {
		super(5, sideLength);
	}
}

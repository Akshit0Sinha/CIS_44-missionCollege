//extension of Rectangle that has perimeter and area already defined, just changed for only needing one input
public class Sqaure extends Rectangle {
	public Sqaure(double side) {
		super(side, side);
	}
}

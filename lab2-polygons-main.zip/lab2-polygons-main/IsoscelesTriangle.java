//  pulls from triangle to change calculation of perimeter and area to fit qualities of Isosceles Triangle
public class IsoscelesTriangle extends Triangle {
	public IsoscelesTriangle(double eqSide, double base) {
		super(eqSide, eqSide, base);
	}
}

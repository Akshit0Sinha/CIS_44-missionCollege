//extends for 8 sided-shape to then pull from regular polygon parameters for area and perimeter

public class Octagon extends RegularPolygon {
	public Octagon(double sideLength) {
		super(8, sideLength);
	}
}

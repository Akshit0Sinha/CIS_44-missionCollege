//base class to then be overrided by other more descript subclasses
public interface Polygon {
	double area();

	double perimeter();
}


//comments because no UML diagram for this project
import java.util.Random;


public class DotProduct {
	// templat-ing and creating integer arrays before defining more about the array
	public static void main(String[] args) {
		int n = 5;
		int[] a = new int[n];
		int[] b = new int[n];
		int[] c = new int[n];

		Random r = new Random();

		// use of random library, has to be 1-10 because otherwise we would be
		// multiplying by a value of 0
		// taking guidelines 3, 4, and 5 for writing code for arrays
		for (int i = 0; i < n; i++) {
			a[i] = r.nextInt(10) + 1;
			b[i] = r.nextInt(10) + 1;
			c[i] = a[i] * b[i];
		}
		// print the arrays for from 0 to 4 for an n value of 5 for output
		System.out.print("Array a: ");
		for (int i = 0; i < n; i++) {
			System.out.print(a[i] + " ");
		}
		System.out.println();

		System.out.print("Array b: ");
		for (int i = 0; i < n; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();

		System.out.print("Array c: ");
		for (int i = 0; i < n; i++) {
			System.out.print(c[i] + " ");
		}
		System.out.println();

	}

}

import java.util.Random;

public class Ecosystem {
	private Animal[] river;
	private final Random r = new Random();

	public Ecosystem(int riverWidth) {
		this.river = new Animal[riverWidth];

		// 0 = empty, 1 = Bear, 2 = Fish
		for (int i = 0; i < riverWidth; i++) {
			int v = r.nextInt(3);
			if (v == 1) {
				river[i] = new Bear();
			} else if (v == 2) {
				river[i] = new FIsh();
			}
		}
	}

	// Simulation of ecosystem in river line by line
	public void checkPosition() {
		Animal[] next = new Animal[river.length];

		for (int i = 0; i < river.length; i++) {
			Animal a = river[i];
			if (a == null) {
				continue;
			}

			int move = r.nextInt(3) - 1;
			int h = i + move;

			if (h < 0) {
				h = 0;
			}
			if (h >= river.length) {
				h = river.length - 1;
			}

			if (next[h] == null) {
				next[h] = a;
			} else {
				Animal b = next[h];
				if (a.getClass() == b.getClass()) {
					// Same species: reproduce into the NEXT array
					placeNewAnimalRandom(a, next);
				} else if (a instanceof Bear && b instanceof FIsh) {
					// Bear eats Fish
					next[h] = a;
				}
				// else: a is Fish and b is Bear -> fish disappears (do nothing)
			}
		}

		river = next;
	}

	//population counter
	public void countPopulation() {
		int bears = 0;
		int fish = 0;
		for (Animal a : river) {
			if (a instanceof Bear) {
				bears++;
			}
			else if (a instanceof FIsh) {
				fish++;
			}
		}
		System.out.println("Bear population: " + bears + " | Fish population: " + fish);
	}

	// Place newborn into a random EMPTY slot of the target river (next state)
	private void placeNewAnimalRandom(Animal parent, Animal[] target) {
		int empties = 0;
		for (Animal x : target) {
			if (x == null) {
				empties++;
			}
		}
		if (empties == 0) {
			return;
		}

		int position;
		do {
			position = r.nextInt(target.length);
		} while (target[position] != null);

		target[position] = parent instanceof Bear ? new Bear() : new FIsh();
	}

	// Text visualization
	public void visualize() {
		for (Animal a : river) {
			System.out.print(a == null ? "-" : a.getVisualSymbol());
			System.out.print(" ");
		}
		System.out.println();
	}

}

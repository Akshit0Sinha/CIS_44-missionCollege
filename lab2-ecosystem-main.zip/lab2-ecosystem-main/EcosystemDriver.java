// call all methods to print into simulation
public class EcosystemDriver {
	public static void main(String[] args) throws InterruptedException {
		Ecosystem e = new Ecosystem(20);
		for (int move = 1; move <= 10; move++) {
			System.out.println("Step " + move + ":");
			e.visualize();
			e.countPopulation();
			e.checkPosition();
			Thread.sleep(300);
			System.out.println();
			System.out.println();
		}
	}
}

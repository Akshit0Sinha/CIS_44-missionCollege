public class FIsh extends Animal {
	@Override
	public String getVisualSymbol() {
		return "F";
	}
}

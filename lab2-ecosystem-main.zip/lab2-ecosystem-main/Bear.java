public class Bear extends Animal {

	@Override
	public String getVisualSymbol() {
		return "B";
	}
}

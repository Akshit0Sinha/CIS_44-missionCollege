import java.util.Random;

public class Matrix {
	private int[][] data;

// constructor rows and columns
	public Matrix(int rows, int columns) {
		if (rows <= 0 || columns <= 0) {
			throw new IllegalArgumentException("Matrix dimensions must be (+,+)");
		}
		data = new int[rows][columns];
	}

// constructor base 2D arrays
	public Matrix(int[][] data) {
		if (data == null) {
			throw new IllegalArgumentException("Data array cannot be null.");
		}
		if (data.length == 0) {
			throw new IllegalArgumentException("Data array must have at least one row.");
		}
		if (data[0].length == 0) {
			throw new IllegalArgumentException("Data array must have at least one column.");
		}

		this.data = new int[data.length][data[0].length];

		for (int i = 0; i < data.length; i++) {
			if (data[i].length != data[0].length) {
				throw new IllegalArgumentException("All rows must have the same length.");
			}
			System.arraycopy(data[i], 0, this.data[i], 0, data[i].length);
		}
	}

// add 2 matrices
	public Matrix add(Matrix other) {
		if (this.data.length != other.data.length || this.data[0].length != other.data[0].length) {
			throw new IllegalArgumentException("Matrices must have the same dimensions to add.");
		}

		int row = data.length;
		int column = data[0].length;
		Matrix result = new Matrix(row, column);

		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				result.data[i][j] = this.data[i][j] + other.data[i][j];
			}
		}
		return result;
	}

	// Multiply 2 matrices
	public Matrix multiply(Matrix other) {
		if (this.data[0].length != other.data.length) {
			throw new IllegalArgumentException("Number of columns of first matrix must equal number of rows of second matrix.");
		}

		int rows = this.data.length;
		int columns = other.data[0].length;
		int common = this.data[0].length;

		Matrix result = new Matrix(rows, columns);

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				int sum = 0;
				for (int k = 0; k < common; k++) {
					sum += this.data[i][k] * other.data[k][j];
				}
				result.data[i][j] = sum;
			}
		}
		return result;
	}

// 1 to 10 random int
	public void populateRandom() {
		Random r = new Random();
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				data[i][j] = r.nextInt(10) + 1; // values 1–10
			}
		}
	}

	// String representation
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		for (int[] row : data) {
			for (int val : row) {
				s.append(val).append("\t");
			}
			s.append("\n");
		}
		return s.toString();
	}
}


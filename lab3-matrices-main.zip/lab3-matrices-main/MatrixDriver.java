public class MatrixDriver {
	public static void main(String[] args) {
		// Create two matrices with random values
		Matrix m1 = new Matrix(2, 3);
		Matrix m2 = new Matrix(2, 3);
		m1.populateRandom();
		m2.populateRandom();

		System.out.println("Matrix m1:");
		System.out.println(m1);

		System.out.println("Matrix m2:");
		System.out.println(m2);

		// Matrix addition
		try {
			Matrix sum = m1.add(m2);
			System.out.println("m1 + m2:");
			System.out.println(sum);
		} catch (IllegalArgumentException e) {
			System.out.println("Addition Error: " + e.getMessage());
		}

		// Multiplication example
		Matrix m3 = new Matrix(3, 2);

		m3.populateRandom();
		System.out.println("Matrix m3:");
		System.out.println(m3);

		try {
			Matrix product = m1.multiply(m3);
			System.out.println("m1 * m3:");
			System.out.println(product);
		} catch (IllegalArgumentException e) {
			System.out.println("Multiplication Error: " + e.getMessage());
		}

		// Exception demonstration: mismatched addition
		try {
			Matrix b = m1.add(m3);
		} catch (IllegalArgumentException e) {
			System.out.println("Expected Exception (Addition): " + e.getMessage());
		}

		// Exception demonstration: mismatched multiplication
		try {
			Matrix bM = m2.multiply(m2);
		} catch (IllegalArgumentException e) {
			System.out.println("Expected Exception (Multiplication): " + e.getMessage());
		}
	}
}
